﻿using HRMS.Application.DTOs;
using HRMS.Application.Interfaces;
using HRMS.Web.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace HRMS.Web.Controllers
{
    // تقرير رواتب الموظفين (المطلوب الثامن)
    [Authorize]
    public class PayrollController : Controller
    {
        private readonly IPayrollService _payrollService;

        private static readonly string[] ArabicMonthNames =
        {
            "يناير", "فبراير", "مارس", "ابريل", "مايو", "يونيو",
            "يوليو", "اغسطس", "سبتمبر", "اكتوبر", "نوفمبر", "ديسمبر"
        };

        public PayrollController(IPayrollService payrollService)
        {
            _payrollService = payrollService;
        }

        public async Task<IActionResult> Index(PayrollSearchViewModel search)
        {
            if (search.Month is < 1 or > 12)
                search.Month = DateTime.Today.Month;

            if (search.Year <= 0)
                search.Year = DateTime.Today.Year;

            var filter = new PayrollSearchFilter
            {
                EmployeeName = search.EmployeeName,
                Month = search.Month,
                Year = search.Year
            };

            var report = await _payrollService.GetReportAsync(filter);

            var model = new PayrollIndexViewModel
            {
                Rows = report.Rows,
                Search = search,
                MonthOptions = BuildMonthOptions(search.Month),
                YearOptions = BuildYearOptions(search.Year),
                SearchError = report.SearchError,
                YearError = report.YearError
            };

            return View(model);
        }

        // الطباعة نفسها بتعتبر اعتماد: اول مرة يتطبع فيها راتب شهر معين لموظف،
        // بيتحفظ كـ Snapshot ثابت ومتتأثرش قيمته بعد كده حتى لو اتعدلت بيانات الحضور
        public async Task<IActionResult> Print(int employeeId, int month, int year)
        {
            var row = await _payrollService.ApproveAsync(employeeId, month, year);
            if (row == null)
                return NotFound();

            ViewBag.MonthName = ArabicMonthNames[month - 1];
            return View(row);
        }

        // اعتماد الراتب من غير طباعة (زرار منفصل فى الجدول)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Approve(int employeeId, int month, int year, string? employeeName)
        {
            var row = await _payrollService.ApproveAsync(employeeId, month, year);
            TempData["SuccessMessage"] = row != null
                ? $"تم اعتماد راتب {row.EmployeeName} بنجاح"
                : "الموظف غير موجود";

            return RedirectToAction(nameof(Index), new { Month = month, Year = year, EmployeeName = employeeName });
        }

        // ---------- Helpers ----------
        private List<SelectListItem> BuildMonthOptions(int selectedMonth)
        {
            return Enumerable.Range(1, 12)
                .Select(m => new SelectListItem
                {
                    Value = m.ToString(),
                    Text = ArabicMonthNames[m - 1],
                    Selected = m == selectedMonth
                })
                .ToList();
        }

        private List<SelectListItem> BuildYearOptions(int selectedYear)
        {
            var minYear = _payrollService.MinimumAllowedYear;
            var maxYear = DateTime.Today.Year;

            var years = Enumerable.Range(minYear, Math.Max(1, maxYear - minYear + 1))
                .Reverse();

            return years
                .Select(y => new SelectListItem
                {
                    Value = y.ToString(),
                    Text = y.ToString(),
                    Selected = y == selectedYear
                })
                .ToList();
        }
    }
}
