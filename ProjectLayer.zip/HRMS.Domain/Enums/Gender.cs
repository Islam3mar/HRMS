﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HRMS.Domain.Enums
{
    public enum Gender
    {
        Male = 1,
        Female = 2
    }
}
